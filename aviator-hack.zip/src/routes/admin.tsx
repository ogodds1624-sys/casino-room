import { useEffect, useRef, useState, type FormEvent, type ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowLeftRight, Diamond, Hexagon, LayoutGrid, List, RefreshCw, RotateCcw, Wallet } from "lucide-react";
import {
  addPartner,
  confirmPayment,
  deletePartner,
  deleteTestimony,
  getAdminSnapshot,
  getPaymentProof,
  rejectPayment,
  saveGatewayCheckout,
  saveGatewayRates,
  setPartnerCommission,
  setPartnerLock,
  setTestimonyStatus,
  type AdminSnapshot,
  type AdminTestimony,
  type BankAccount,
  type GatewayCheckout,
  type GatewaySettings,
  type MomoWallet,
} from "@/lib/admin-snapshot";
import { bumpGateway } from "@/lib/storefront-live";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
});

const ADMIN_PASS = "8057";
const ADMIN_KEY = "aviator-admin-open";
const NAV = [
  { id: "overview", label: "OVERVIEW", icon: LayoutGrid },
  { id: "members", label: "MEMBERS", icon: List },
  { id: "transactions", label: "TRANSACTIONS", icon: ArrowLeftRight },
  { id: "partners", label: "PARTNERS", icon: Hexagon },
  { id: "gateway", label: "PAYMENT GATEWAY", icon: Wallet },
] as const;

type Tab = (typeof NAV)[number]["id"];

const PACKAGE_NOTE: Record<number, string> = {
  300: "3 mins per session",
  400: "5 mins per session",
  500: "7 mins per session",
  35000: "3 mins per session",
  55000: "5 mins per session",
  75000: "7 mins per session",
};

function moneyLabel(amount: number) {
  return amount === 35000 || amount === 55000 || amount === 75000
    ? `₦${amount.toLocaleString("en-NG")}`
    : `GHS ${amount.toLocaleString("en-GH")}`;
}

function GhanaFlag() {
  return (
    <svg viewBox="0 0 24 16" className="h-4 w-6" aria-hidden>
      <rect width="24" height="5.34" fill="#ce1126" />
      <rect y="5.33" width="24" height="5.34" fill="#fcd116" />
      <rect y="10.66" width="24" height="5.34" fill="#006b3f" />
      <polygon points="12,6.2 12.7,8.2 14.8,8.2 13.1,9.4 13.8,11.4 12,10.2 10.2,11.4 10.9,9.4 9.2,8.2 11.3,8.2" fill="#000" />
    </svg>
  );
}

function NigeriaFlag() {
  return (
    <svg viewBox="0 0 24 16" className="h-4 w-6" aria-hidden>
      <rect width="8" height="16" fill="#008751" />
      <rect x="8" width="8" height="16" fill="#fff" />
      <rect x="16" width="8" height="16" fill="#008751" />
    </svg>
  );
}

const EMPTY_CHECKOUT: GatewayCheckout = {
  currency: "GHS",
  businessName: "Aviator Hack",
  whatsapp: "",
  email: "",
  paystack: false,
  flutterwave: false,
  royaltech: false,
  cowrie: false,
  momo: false,
  bank: false,
  nigeriaOn: false,
  nigeriaBanks: [],
  wallets: [],
  banks: [],
};

const EMPTY_SNAPSHOT: AdminSnapshot = {
  members: [],
  payments: [],
  partners: [],
  testimonies: [],
  total: 0,
  today: 0,
  revenue: 0,
  confirmed: 0,
  gateway: {
    scansRemaining: 0,
    scansUsed: 0,
    nigeria: 0,
    kenya: 0,
    tanzania: 0,
    zambia: 0,
    southAfrica: 0,
    checkout: EMPTY_CHECKOUT,
  },
};

const memberCols = "desk-row grid-cols-[minmax(0,1.4fr)_5.5rem_7.5rem_9rem]";
const txCols = "desk-row grid-cols-[6.5rem_minmax(0,1.1fr)_minmax(0,0.9fr)_minmax(0,0.9fr)_8.5rem_7.5rem]";

function AdminPage() {
  const [unlocked, setUnlocked] = useState(false);
  const [code, setCode] = useState("");
  const [denied, setDenied] = useState(false);
  const [snapshot, setSnapshot] = useState<AdminSnapshot | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [spinning, setSpinning] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [partnerNotice, setPartnerNotice] = useState<string | null>(null);
  const knownPayments = useRef<Set<string> | null>(null);
  const knownPartners = useRef<Set<string> | null>(null);
  const title = NAV.find((item) => item.id === tab)?.label ?? "OVERVIEW";

  useEffect(() => {
    if (window.sessionStorage.getItem(ADMIN_KEY) === "1") setUnlocked(true);
  }, []);

  useEffect(() => {
    if (!unlocked) return;
    let live = true;
    const load = () => {
      void getAdminSnapshot()
        .then((data) => {
          if (!live) return;
          const pending = data.payments.filter((payment) => payment.status === "pending");
          if (knownPayments.current) {
            const fresh = pending.filter((payment) => !knownPayments.current?.has(payment.id));
            if (fresh.length > 0) {
              const latest = fresh[0];
              const text =
                fresh.length === 1
                  ? `${latest.payerName} sent ${moneyLabel(latest.amount)}`
                  : `${fresh.length} new payments · ${latest.payerName} sent ${moneyLabel(latest.amount)}`;
              setNotice(text);
              window.localStorage.setItem("aviator-tx-notice", text);
            }
          } else {
            const saved = window.localStorage.getItem("aviator-tx-notice");
            if (saved) setNotice(saved);
          }
          knownPayments.current = new Set(data.payments.map((payment) => payment.id));
          const waitingPartners = data.partners.filter((partner) => partner.status === "pending");
          if (knownPartners.current) {
            const freshPartners = waitingPartners.filter((partner) => !knownPartners.current?.has(partner.id));
            if (freshPartners.length > 0) {
              setPartnerNotice(`${freshPartners[0].name} applied as a partner`);
            }
          }
          knownPartners.current = new Set(data.partners.map((partner) => partner.id));
          setSnapshot(data);
        })
        .catch(() => {
          if (!live) return;
        });
    };
    load();
    const id = window.setInterval(load, 3000);
    return () => {
      live = false;
      window.clearInterval(id);
    };
  }, [unlocked]);

  function unlock(event: FormEvent) {
    event.preventDefault();
    if (code.trim() === ADMIN_PASS) {
      window.sessionStorage.setItem(ADMIN_KEY, "1");
      setUnlocked(true);
      setDenied(false);
      return;
    }
    setDenied(true);
  }

  async function refresh() {
    setSpinning(true);
    try {
      setSnapshot(await getAdminSnapshot());
    } finally {
      setSpinning(false);
    }
  }

  async function confirm(id: string) {
    setSpinning(true);
    try {
      setSnapshot(await confirmPayment({ data: { id } }));
    } finally {
      setSpinning(false);
    }
  }

  async function reject(id: string) {
    setSpinning(true);
    try {
      setSnapshot(await rejectPayment({ data: { id } }));
    } finally {
      setSpinning(false);
    }
  }

  const view = snapshot ?? EMPTY_SNAPSHOT;
  const nairaAmount = (amount: number) => amount === 35000 || amount === 55000 || amount === 75000;
  const accraToday = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Accra",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
  const confirmed = view.payments.filter((payment) => payment.status === "confirmed");
  const isToday = (iso: string) =>
    Boolean(iso) &&
    new Intl.DateTimeFormat("en-CA", {
      timeZone: "Africa/Accra",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date(iso)) === accraToday;
  const ghanaPayments = confirmed.filter((payment) => !nairaAmount(payment.amount));
  const nigeriaPayments = confirmed.filter((payment) => nairaAmount(payment.amount));
  const ghanaRevenue = ghanaPayments.reduce((sum, payment) => sum + payment.amount, 0);
  const nigeriaRevenue = nigeriaPayments.reduce((sum, payment) => sum + payment.amount, 0);
  const ghanaDaily = ghanaPayments.filter((payment) => isToday(payment.confirmedAt)).reduce((sum, payment) => sum + payment.amount, 0);
  const nigeriaDaily = nigeriaPayments.filter((payment) => isToday(payment.confirmedAt)).reduce((sum, payment) => sum + payment.amount, 0);
  const pendingCount = view.payments.filter((payment) => payment.status === "pending").length;
  const partnerWait = view.partners.filter((partner) => partner.status === "pending").length;

  function openTab(next: Tab) {
    setTab(next);
    if (next === "transactions") {
      setNotice(null);
      window.localStorage.removeItem("aviator-tx-notice");
    }
    if (next === "partners") setPartnerNotice(null);
  }

  if (!unlocked) {
    return (
      <main className="flex min-h-dvh items-center justify-center bg-ink px-4 text-white">
        <form onSubmit={unlock} className="w-full max-w-xs">
          <label htmlFor="admin-pass" className="text-xs font-extrabold tracking-[0.16em] text-white/70">
            PASSCODE
          </label>
          <input
            id="admin-pass"
            value={code}
            onChange={(event) => setCode(event.target.value)}
            inputMode="numeric"
            autoComplete="off"
            className="mt-3 h-12 w-full rounded-xl border border-line bg-panel px-3 text-center text-lg tracking-[0.3em] text-white outline-none"
          />
          {denied ? <p className="mt-2 text-sm text-red">Wrong passcode.</p> : null}
          <button type="submit" className="mt-4 h-12 w-full rounded-xl bg-red text-sm font-extrabold tracking-wide text-white">
            ENTER
          </button>
        </form>
      </main>
    );
  }

  return (
    <main className="admin-desk desk-shell bg-ink text-white">
      <aside className="admin-side border-r border-white/10 bg-ink px-4 py-6 text-white">
        <div className="flex items-start justify-between gap-2 px-2">
          <div className="flex items-start gap-2">
            <Diamond className="mt-1 size-4 shrink-0 fill-red text-red" aria-hidden />
            <span className="text-xl leading-tight font-black tracking-tight">
              Aviator
              <br />
              Hack
            </span>
          </div>
          <span className="rounded-full border border-red px-2.5 py-1 text-[11px] font-extrabold tracking-wide text-red">ADMIN</span>
        </div>
        <nav className="mt-8 space-y-1">
          {NAV.map((item) => {
            const Icon = item.icon;
            const active = tab === item.id;
            const count = item.id === "transactions" ? pendingCount : item.id === "partners" ? partnerWait : 0;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => openTab(item.id)}
                className={
                  "flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left text-sm font-extrabold tracking-wide " +
                  (active ? "bg-red text-white" : "text-[#6b7280]")
                }
              >
                <Icon className="size-4 shrink-0" aria-hidden />
                <span className="min-w-0 flex-1">{item.label}</span>
                {count > 0 ? (
                  <span className="grid min-w-5 place-items-center rounded-full bg-white px-1.5 text-[10px] font-black text-red">{count}</span>
                ) : null}
              </button>
            );
          })}
        </nav>
      </aside>
      <section className="min-w-0 flex-1">
        <header className="admin-mobile-nav border-b border-white/10 bg-ink">
          <div className="flex items-center gap-3 px-4 py-3">
            <Diamond className="size-4 shrink-0 fill-red text-red" aria-hidden />
            <span className="truncate text-lg font-black tracking-tight">Aviator Hack</span>
            <span className="rounded-full border border-red px-2.5 py-1 text-[11px] font-extrabold tracking-wide text-red">ADMIN</span>
          </div>
          <nav className="flex gap-1 overflow-x-auto px-3 pb-3">
            {NAV.map((item) => {
              const active = tab === item.id;
              const count = item.id === "transactions" ? pendingCount : item.id === "partners" ? partnerWait : 0;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => openTab(item.id)}
                  className={"inline-flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-extrabold tracking-wide " + (active ? "bg-red text-white" : "text-[#9aa3b2]")}
                >
                  {item.label}
                  {count > 0 ? (
                    <span className="grid min-w-4 place-items-center rounded-full bg-white px-1 text-[10px] font-black text-red">{count}</span>
                  ) : null}
                </button>
              );
            })}
          </nav>
        </header>
        <div className="admin-content">
          <p className="flex items-center gap-2 text-xs font-extrabold tracking-[0.16em] text-red">
            <Diamond className="size-3 fill-red" aria-hidden />
            CONTROL ROOM
          </p>
          <div className="admin-title mt-2">
            <h1 className="font-black tracking-tight capitalize">
              {tab === "overview" ? "Overview" : tab === "transactions" ? "Transaction History" : title.toLowerCase()}
            </h1>
            <button
              type="button"
              onClick={() => void refresh()}
              className="inline-flex h-11 items-center gap-2 rounded-xl border border-white/10 bg-[#111111] px-3 text-xs font-extrabold tracking-wide text-white"
            >
              <RefreshCw className={"size-4 " + (spinning ? "animate-spin" : "")} aria-hidden />
              REFRESH
            </button>
          </div>
          {notice ? (
            <button type="button" onClick={() => openTab("transactions")} className="mt-4 flex w-full items-center justify-between gap-3 rounded-2xl border border-[#f3b4b4] bg-red/15 px-4 py-3 text-left text-sm font-bold">
              <span>{notice}</span>
              <span className="shrink-0 text-xs font-extrabold tracking-wide text-[#ff8d8d]">{pendingCount} PENDING</span>
            </button>
          ) : null}
          {partnerWait > 0 ? (
            <button type="button" onClick={() => openTab("partners")} className="mt-4 flex w-full items-center justify-between gap-3 rounded-2xl border border-[#f3b4b4] bg-red/15 px-4 py-3 text-left text-sm font-bold">
              <span>{partnerNotice ?? "A new partner is waiting for approval"}</span>
              <span className="shrink-0 text-xs font-extrabold tracking-wide text-[#ff8d8d]">{partnerWait} TO APPROVE</span>
            </button>
          ) : null}

          {tab === "overview" ? (
            <>
              <TestimonyDesk rows={view.testimonies} busy={spinning} onChange={setSnapshot} onBusy={setSpinning} />
              <h2 className="mt-8 text-2xl font-black">At a glance</h2>
              <p className="mt-1 text-base text-[#8b95a7]">Live snapshot of accounts that connected SportyBet.</p>
              <div className="stat-grid mt-4">
                <StatCard label="TOTAL MEMBERS" value={String(view.total)} note={`${view.total} connected accounts`} icon={<List className="size-5" />} />
                <StatCard label="TODAY" value={String(view.today)} note={`${view.today} accounts today`} icon={<List className="size-5" />} />
              </div>
              <MemberList members={view.members} />
              <div className="stat-grid mt-8">
                <StatCard label="DAILY GHANA" value={`GHS ${ghanaDaily.toLocaleString("en-GH")}`} note="Resets at 23:59" gold icon={<GhanaFlag />} iconClass="bg-white/10" />
                <StatCard label="TOTAL GHANA" value={`GHS ${ghanaRevenue.toLocaleString("en-GH")}`} note="Does not reset" gold icon={<GhanaFlag />} iconClass="bg-white/10" />
              </div>
              <WeekRevenue payments={view.payments} country="Ghana" />
              <div className="stat-grid mt-4">
                <StatCard label="DAILY NIGERIA" value={`₦${nigeriaDaily.toLocaleString("en-NG")}`} note="Resets at 23:59" icon={<NigeriaFlag />} iconClass="bg-white/10" />
                <StatCard label="TOTAL NIGERIA" value={`₦${nigeriaRevenue.toLocaleString("en-NG")}`} note="Does not reset" icon={<NigeriaFlag />} iconClass="bg-white/10" />
              </div>
              <WeekRevenue payments={view.payments} country="Nigeria" />
            </>
          ) : tab === "transactions" ? (
            <TransactionHistory payments={view.payments} busy={spinning} onConfirm={(id) => void confirm(id)} onReject={(id) => void reject(id)} />
          ) : tab === "members" ? (
            <div className="mt-8">
              <MemberList members={view.members} />
            </div>
          ) : tab === "partners" ? (
            <PartnerDesk partners={view.partners} busy={spinning} onChange={setSnapshot} onBusy={setSpinning} />
          ) : (
            <PaymentGateway gateway={view.gateway} busy={spinning} onChange={setSnapshot} onBusy={setSpinning} />
          )}
        </div>
      </section>
    </main>
  );
}

function PaymentGateway({
  gateway,
  busy,
  onChange,
  onBusy,
}: {
  gateway: GatewaySettings;
  busy: boolean;
  onChange: (snapshot: AdminSnapshot) => void;
  onBusy: (busy: boolean) => void;
}) {
  const [rates, setRates] = useState({
    nigeria: gateway.nigeria ? String(gateway.nigeria) : "",
    kenya: gateway.kenya ? String(gateway.kenya) : "",
    tanzania: gateway.tanzania ? String(gateway.tanzania) : "",
    zambia: gateway.zambia ? String(gateway.zambia) : "",
    southAfrica: gateway.southAfrica ? String(gateway.southAfrica) : "",
  });
  const [error, setError] = useState<string | null>(null);
  const fields = [
    ["nigeria", "NIGERIA — ₦ PER GHS"],
    ["kenya", "KENYA — KSH PER GHS"],
    ["tanzania", "TANZANIA — TSH PER GHS"],
    ["zambia", "ZAMBIA — ZK PER GHS"],
    ["southAfrica", "SOUTH AFRICA — R PER GHS"],
  ] as const;

  return (
    <div className="mt-6 space-y-4">
      <section className="rounded-3xl border border-white/10 bg-[#111111] px-4 py-5">
        <h2 className="text-lg font-black">Exchange Rates</h2>
        <form
          className="mt-4"
          onSubmit={(event) => {
            event.preventDefault();
            setError(null);
            onBusy(true);
            void saveGatewayRates({
              data: {
                nigeria: Number(rates.nigeria),
                kenya: Number(rates.kenya),
                tanzania: Number(rates.tanzania),
                zambia: Number(rates.zambia),
                southAfrica: Number(rates.southAfrica),
              },
            })
              .then((next) => {
                bumpGateway();
                onChange(next);
              })
              .catch((err) => setError(err instanceof Error ? err.message : "Could not save rates."))
              .finally(() => onBusy(false));
          }}
        >
          <div className="grid gap-4 md:grid-cols-2">
            {fields.map(([key, label]) => (
              <label key={key} className="block">
                <span className="text-[11px] font-bold tracking-[0.12em] text-[#9aa3b2]">{label}</span>
                <span className="mt-1 flex items-center gap-2">
                  <input
                    value={rates[key]}
                    onChange={(event) => setRates((current) => ({ ...current, [key]: event.target.value }))}
                    inputMode="decimal"
                    className="h-11 min-w-0 flex-1 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none"
                  />
                  <button
                    type="button"
                    aria-label={`Reset ${label}`}
                    onClick={() => setRates((current) => ({ ...current, [key]: "" }))}
                    className="grid size-9 shrink-0 place-items-center rounded-full border border-white/15 text-[#9aa3b2]"
                  >
                    <RotateCcw className="size-3.5" aria-hidden />
                  </button>
                </span>
              </label>
            ))}
          </div>
          {error ? <p className="mt-3 text-sm text-red">{error}</p> : null}
          <button type="submit" disabled={busy} className="mt-5 h-11 rounded-lg bg-red px-5 text-sm font-extrabold tracking-wide text-white disabled:opacity-60">
            SAVE RATES
          </button>
        </form>
      </section>
      <CheckoutSettings gateway={gateway} busy={busy} onChange={onChange} onBusy={onBusy} />
    </div>
  );
}

function CheckoutSettings({
  gateway,
  busy,
  onChange,
  onBusy,
}: {
  gateway: GatewaySettings;
  busy: boolean;
  onChange: (snapshot: AdminSnapshot) => void;
  onBusy: (busy: boolean) => void;
}) {
  const [form, setForm] = useState<GatewayCheckout>(gateway.checkout);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setForm(gateway.checkout);
  }, [gateway.checkout]);

  function patchList<T>(key: "wallets" | "banks" | "nigeriaBanks", index: number, patch: Partial<T>) {
    setForm((current) => ({
      ...current,
      [key]: current[key].map((item, itemIndex) => (itemIndex === index ? { ...item, ...patch } : item)),
    }));
  }

  return (
    <section className="rounded-3xl border border-white/10 bg-[#111111] px-4 py-5">
      <h2 className="text-lg font-black">Checkout</h2>
      <form
        className="mt-4 grid gap-4"
        onSubmit={(event) => {
          event.preventDefault();
          setError(null);
          onBusy(true);
          void saveGatewayCheckout({ data: form })
            .then((next) => {
              bumpGateway();
              onChange(next);
            })
            .catch((err) => setError(err instanceof Error ? err.message : "Could not save checkout."))
            .finally(() => onBusy(false));
        }}
      >
        <label className="block">
          <span className="text-[11px] font-bold tracking-[0.14em] text-[#9aa3b2]">BUSINESS / DISPLAY NAME</span>
          <input value={form.businessName} onChange={(event) => setForm((current) => ({ ...current, businessName: event.target.value }))} className="mt-1 h-11 w-full rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
        </label>
        <label className="block">
          <span className="text-[11px] font-bold tracking-[0.14em] text-[#9aa3b2]">WHATSAPP SUPPORT NUMBER</span>
          <input value={form.whatsapp} onChange={(event) => setForm((current) => ({ ...current, whatsapp: event.target.value }))} className="mt-1 h-11 w-full rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
        </label>
        <label className="block">
          <span className="text-[11px] font-bold tracking-[0.14em] text-[#9aa3b2]">SUPPORT EMAIL</span>
          <input value={form.email} onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))} className="mt-1 h-11 w-full rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
        </label>
        <Toggle label="Ghana MoMo" on={form.momo} onClick={() => setForm((current) => ({ ...current, momo: !current.momo }))} />
        {form.wallets.map((wallet, index) => (
          <div key={`wallet-${index}`} className="grid gap-2 md:grid-cols-3">
            <input value={wallet.network} onChange={(event) => patchList<MomoWallet>("wallets", index, { network: event.target.value })} placeholder="Network" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
            <input value={wallet.number} onChange={(event) => patchList<MomoWallet>("wallets", index, { number: event.target.value })} placeholder="Number" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
            <input value={wallet.name} onChange={(event) => patchList<MomoWallet>("wallets", index, { name: event.target.value })} placeholder="Name" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
          </div>
        ))}
        <button type="button" onClick={() => setForm((current) => ({ ...current, wallets: [...current.wallets, { network: "Telecel Cash (Vodafone)", number: "", name: "" }] }))} className="h-10 w-fit rounded-lg border border-white/15 px-3 text-xs font-extrabold">
          ADD MOMO
        </button>
        <Toggle label="Ghana bank" on={form.bank} onClick={() => setForm((current) => ({ ...current, bank: !current.bank }))} />
        {form.banks.map((account, index) => (
          <BankFields key={`bank-${index}`} account={account} onChange={(patch) => patchList<BankAccount>("banks", index, patch)} />
        ))}
        <button type="button" onClick={() => setForm((current) => ({ ...current, banks: [...current.banks, { bank: "", number: "", name: "" }] }))} className="h-10 w-fit rounded-lg border border-white/15 px-3 text-xs font-extrabold">
          ADD BANK
        </button>
        <Toggle label="Nigeria bank transfer" on={form.nigeriaOn} onClick={() => setForm((current) => ({ ...current, nigeriaOn: !current.nigeriaOn }))} />
        {form.nigeriaBanks.map((account, index) => (
          <BankFields key={`ng-${index}`} account={account} onChange={(patch) => patchList<BankAccount>("nigeriaBanks", index, patch)} />
        ))}
        <button type="button" onClick={() => setForm((current) => ({ ...current, nigeriaBanks: [...current.nigeriaBanks, { bank: "", number: "", name: "" }] }))} className="h-10 w-fit rounded-lg border border-white/15 px-3 text-xs font-extrabold">
          ADD NIGERIA ACCOUNT
        </button>
        {error ? <p className="text-sm text-red">{error}</p> : null}
        <button type="submit" disabled={busy} className="h-11 w-fit rounded-lg bg-red px-5 text-sm font-extrabold tracking-wide text-white disabled:opacity-60">
          SAVE SETTINGS
        </button>
      </form>
    </section>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex items-center justify-between gap-3 rounded-xl border border-white/10 px-3 py-3 text-left">
      <span className="text-sm font-extrabold">{label}</span>
      <span className={"relative h-7 w-12 rounded-full " + (on ? "bg-[#4b5563]" : "bg-[#e5e7eb]")}>
        <span className={"absolute top-0.5 size-6 rounded-full bg-white shadow " + (on ? "right-0.5" : "left-0.5")} />
      </span>
    </button>
  );
}

function BankFields({ account, onChange }: { account: BankAccount; onChange: (patch: Partial<BankAccount>) => void }) {
  return (
    <div className="grid gap-2 md:grid-cols-3">
      <input value={account.bank} onChange={(event) => onChange({ bank: event.target.value })} placeholder="Bank" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
      <input value={account.number} onChange={(event) => onChange({ number: event.target.value })} placeholder="Account number" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
      <input value={account.name} onChange={(event) => onChange({ name: event.target.value })} placeholder="Account name" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
    </div>
  );
}

function PartnerDesk({
  partners,
  busy,
  onChange,
  onBusy,
}: {
  partners: AdminSnapshot["partners"];
  busy: boolean;
  onChange: (snapshot: AdminSnapshot) => void;
  onBusy: (busy: boolean) => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState("");

  async function run(task: () => Promise<AdminSnapshot>) {
    setError(null);
    onBusy(true);
    try {
      onChange(await task());
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not update partners.");
    } finally {
      onBusy(false);
    }
  }

  async function copy(id: string, value: string) {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(id);
      window.setTimeout(() => setCopied(""), 1200);
    } catch {
      setCopied("");
    }
  }

  return (
    <div className="mt-6 space-y-4">
      <section className="rounded-3xl border border-white/10 bg-[#111111] px-4 py-5">
        <h2 className="text-lg font-black">Add a Partner</h2>
        <form
          className="mt-4 grid gap-3 md:grid-cols-2"
          onSubmit={(event) => {
            event.preventDefault();
            void run(async () => {
              const next = await addPartner({ data: { name, email, password, code } });
              setName("");
              setEmail("");
              setPassword("");
              setCode("");
              return next;
            });
          }}
        >
          <input value={name} onChange={(event) => setName(event.target.value)} placeholder="Name" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
          <input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="Email" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
          <input value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Password" type="password" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
          <input value={code} onChange={(event) => setCode(event.target.value)} placeholder="Code (optional)" className="h-11 rounded-lg border border-white/15 bg-ink px-3 text-sm outline-none" />
          {error ? <p className="text-sm text-red md:col-span-2">{error}</p> : null}
          <button type="submit" disabled={busy} className="h-11 w-fit rounded-lg bg-red px-5 text-sm font-extrabold tracking-wide text-white disabled:opacity-60">
            ADD PARTNER
          </button>
        </form>
      </section>
      <section className="overflow-hidden rounded-3xl border border-white/10 bg-[#111111]">
        <div className="px-4 py-4">
          <h2 className="text-lg font-black">Partners</h2>
          <p className="mt-1 text-sm text-[#8b95a7]">Members who open /?ref=CODE are credited to this partner in Ghana and Nigeria.</p>
        </div>
        <div className="desk-row desk-head grid-cols-[minmax(0,1.2fr)_6rem_7rem_minmax(0,1.2fr)_4.5rem_7rem_8rem] text-[11px] tracking-[0.12em]">
          <span>PARTNER</span>
          <span>STATUS</span>
          <span>CODE</span>
          <span>REFERRAL LINK</span>
          <span>COMMISSION</span>
          <span>REVENUE</span>
          <span>ACTIONS</span>
        </div>
        {partners.length === 0 ? (
          <p className="px-4 py-5 text-sm text-[#6b7280]">No partners yet.</p>
        ) : (
          partners.map((partner) => {
            const link = `${window.location.origin}/?ref=${partner.code}`;
            return (
              <article key={partner.id} className="desk-row grid-cols-[minmax(0,1.2fr)_6rem_7rem_minmax(0,1.2fr)_4.5rem_7rem_8rem] text-sm">
                <div className="min-w-0">
                  <p className="truncate font-extrabold">{partner.name}</p>
                  <p className="truncate text-xs text-[#6b7280]">{partner.email}</p>
                </div>
                <span className={partner.status === "approved" ? "pill-active" : "pill-unpaid"}>
                  {partner.status === "approved" ? "APPROVED" : partner.status === "pending" ? "PENDING" : "LOCKED"}
                </span>
                <div className="flex min-w-0 items-center gap-2">
                  <span className="truncate font-bold">{partner.code}</span>
                  <button type="button" onClick={() => void copy(partner.id, partner.code)} className="shrink-0 text-[10px] font-extrabold text-[#9aa3b2]">
                    {copied === partner.id ? "COPIED" : "COPY"}
                  </button>
                </div>
                <div className="min-w-0">
                  <button type="button" onClick={() => void copy(`${partner.id}-link`, link)} className="truncate text-xs font-bold text-white">
                    {copied === `${partner.id}-link` ? "COPIED" : partner.code}
                  </button>
                </div>
                <CommissionRate value={partner.commission} disabled={busy} onSave={(commission) => void run(() => setPartnerCommission({ data: { id: partner.id, commission } }))} />
                <span className="text-xs font-bold leading-4">
                  GHS {partner.revenue.toLocaleString("en-GH")}
                  <br />₦{partner.nigeriaRevenue.toLocaleString("en-NG")}
                </span>
                <div className="flex flex-col items-start gap-1">
                  {partner.status === "pending" ? (
                    <button type="button" disabled={busy} onClick={() => void run(() => setPartnerLock({ data: { id: partner.id, locked: false } }))} className="h-7 rounded-lg bg-red px-2 text-[10px] font-extrabold text-white disabled:opacity-60">
                      APPROVE
                    </button>
                  ) : (
                    <button type="button" disabled={busy} onClick={() => void run(() => setPartnerLock({ data: { id: partner.id, locked: partner.status === "approved" } }))} className="h-7 rounded-lg border border-white/15 px-2 text-[10px] font-extrabold disabled:opacity-60">
                      {partner.status === "approved" ? "LOCK" : "UNLOCK"}
                    </button>
                  )}
                  <button type="button" disabled={busy} onClick={() => void run(() => deletePartner({ data: { id: partner.id } }))} className="h-7 rounded-lg border border-red/80 px-2 text-[10px] font-extrabold text-red disabled:opacity-60">
                    DELETE
                  </button>
                </div>
              </article>
            );
          })
        )}
      </section>
    </div>
  );
}

function CommissionRate({ value, disabled, onSave }: { value: number; disabled: boolean; onSave: (commission: number) => void }) {
  const [draft, setDraft] = useState(value > 0 ? String(value) : "");
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (!focused) setDraft(value > 0 ? String(value) : "");
  }, [value, focused]);

  function save() {
    const next = Number(draft);
    if (!Number.isInteger(next) || next < 0 || next > 100) {
      setDraft(value > 0 ? String(value) : "");
      return;
    }
    if (next !== value) onSave(next);
  }

  return (
    <input
      value={draft}
      inputMode="numeric"
      disabled={disabled}
      placeholder="%"
      aria-label="Commission percent"
      onChange={(event) => setDraft(event.target.value.replace(/[^\d]/g, "").slice(0, 3))}
      onFocus={() => setFocused(true)}
      onBlur={() => {
        setFocused(false);
        save();
      }}
      onKeyDown={(event) => {
        if (event.key === "Enter") event.currentTarget.blur();
      }}
      className="h-8 w-14 rounded-lg border border-white/15 bg-ink px-1 text-center text-xs font-bold text-white outline-none"
    />
  );
}

function TransactionHistory({
  payments,
  busy,
  onConfirm,
  onReject,
}: {
  payments: AdminSnapshot["payments"];
  busy: boolean;
  onConfirm: (id: string) => void;
  onReject: (id: string) => void;
}) {
  const [proof, setProof] = useState<string | null>(null);
  const [opening, setOpening] = useState("");
  const pending = payments.filter((payment) => payment.status === "pending").length;

  async function openProof(id: string) {
    setOpening(id);
    try {
      const row = await getPaymentProof({ data: { id } });
      setProof(row.receipt || "missing");
    } finally {
      setOpening("");
    }
  }

  return (
    <section className="mt-6 overflow-hidden rounded-3xl border border-white/10 bg-[#111111]">
      <div className="flex flex-wrap items-center gap-2 px-4 py-4">
        <h2 className="text-lg font-black">Payments — Confirm</h2>
        <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-bold text-[#6b7280]">
          {payments.length} · {pending} pending
        </span>
      </div>
      <div className={txCols + " desk-head text-[11px] tracking-[0.14em]"}>
        <span>DATE</span>
        <span>MEMBER</span>
        <span>PACKAGE</span>
        <span>PAYMENT PROOF</span>
        <span className="text-center">REFERRED BY</span>
        <span className="text-center">STATUS</span>
      </div>
      {payments.length === 0 ? (
        <p className="px-4 py-5 text-sm text-[#6b7280]">No payments yet.</p>
      ) : (
        payments.map((payment) => {
          const date = payment.createdAt ? new Date(payment.createdAt) : null;
          return (
            <article key={payment.id} className={txCols}>
              <div className="text-xs leading-4 text-[#6b7280]">
                <p>{date ? date.toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }) : "—"}</p>
                <p>{date ? date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : ""}</p>
              </div>
              <div className="min-w-0">
                <p className="truncate font-extrabold">{payment.memberName ?? payment.payerName}</p>
                <p className="truncate text-sm text-[#6b7280]">{payment.memberEmail ?? "—"}</p>
              </div>
              <div className="min-w-0">
                <p className="font-extrabold">{moneyLabel(payment.amount)}</p>
                <p className="text-sm text-[#6b7280]">{PACKAGE_NOTE[payment.amount] ?? ""}</p>
              </div>
              <div className="min-w-0">
                {(payment.country === "Nigeria" || (!payment.country && (payment.amount === 35000 || payment.amount === 55000 || payment.amount === 75000))) ? (
                  payment.hasReceipt ? (
                    <button type="button" disabled={opening === payment.id} onClick={() => void openProof(payment.id)} className="rounded-lg border border-[#86d4a0] px-2 py-1 text-[10px] font-extrabold text-[#7ddea0] disabled:opacity-60">
                      {opening === payment.id ? "Opening…" : "Open picture"}
                    </button>
                  ) : (
                    <p className="text-xs text-[#6b7280]">No proof</p>
                  )
                ) : (
                  <p className="truncate text-sm font-semibold">{payment.payerName || "—"}</p>
                )}
              </div>
              <div className="flex justify-center">
                {payment.referredBy ? (
                  <span className="max-w-full truncate rounded-full border border-white/10 bg-white/10 px-2 py-1 text-[10px] font-bold">{payment.referredBy}</span>
                ) : (
                  <span className="text-xs text-[#9aa3b2]">—</span>
                )}
              </div>
              <div className="flex flex-col items-center gap-2">
                <span className={payment.status === "confirmed" ? "pill-active" : "pill-unpaid"}>
                  {payment.status === "confirmed" ? "RECEIVED" : payment.status === "rejected" ? "REJECTED" : "PENDING"}
                </span>
                {payment.status === "pending" ? (
                  <>
                    <button type="button" disabled={busy} onClick={() => onConfirm(payment.id)} className="rounded-full border border-[#86d4a0] px-2 py-1 text-[10px] font-extrabold text-[#128a3e] disabled:opacity-60">
                      MONEY RECEIVED
                    </button>
                    <button type="button" disabled={busy} onClick={() => onReject(payment.id)} className="rounded-full border border-[#f3b4b4] px-2 py-1 text-[10px] font-extrabold text-[#e23b3b] disabled:opacity-60">
                      × REJECT
                    </button>
                  </>
                ) : null}
              </div>
            </article>
          );
        })
      )}
      {proof ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 px-4" role="dialog">
          <div className="max-h-[90dvh] w-full max-w-md overflow-auto rounded-[28px] border border-line bg-panel">
            <div className="flex items-center justify-between gap-3 px-5 py-4">
              <p className="text-sm font-extrabold">Payment proof</p>
              <button type="button" onClick={() => setProof(null)} className="text-sm font-bold">
                Close
              </button>
            </div>
            {proof === "missing" ? (
              <p className="px-5 pb-5 text-sm text-white/70">No file was attached.</p>
            ) : proof.startsWith("data:image/") ? (
              <img src={proof} alt="Payment receipt" className="w-full bg-ink object-contain" />
            ) : (
              <a href={proof} target="_blank" rel="noreferrer" className="block px-5 pb-5 text-sm font-extrabold text-[#7ddea0]">
                Open the uploaded file
              </a>
            )}
          </div>
        </div>
      ) : null}
    </section>
  );
}

function MemberList({ members }: { members: AdminSnapshot["members"] }) {
  const [query, setQuery] = useState("");
  const needle = query.trim().toLowerCase();
  const shown = needle
    ? members.filter((member) => [member.name, member.email, member.referredBy ?? ""].some((value) => value.toLowerCase().includes(needle)))
    : members;

  return (
    <section className="mt-6 overflow-hidden rounded-3xl border border-white/10 bg-[#111111]">
      <div className="px-4 py-5">
        <h2 className="text-2xl font-black">Members</h2>
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search name, email or partner"
          className="mt-4 h-12 w-full rounded-xl border border-white/15 bg-ink px-3 text-sm outline-none"
        />
      </div>
      <div className={memberCols + " desk-head text-[11px] tracking-[0.14em]"}>
        <span>MEMBER</span>
        <span className="text-center">JOINED</span>
        <span className="text-center">STATUS</span>
        <span className="text-center">REFERRED BY</span>
      </div>
      {shown.length === 0 ? (
        <p className="px-4 py-5 text-sm text-[#6b7280]">{members.length === 0 ? "No accounts yet." : "No members match that search."}</p>
      ) : (
        shown.map((member) => {
          const date = member.createdAt ? new Date(member.createdAt) : null;
          return (
            <article key={member.id} className={memberCols}>
              <div className="min-w-0">
                <p className="truncate font-extrabold">{member.name}</p>
                <p className="truncate text-sm text-[#6b7280]">{member.email}</p>
              </div>
              <div className="text-center text-xs leading-4 text-[#6b7280]">
                <p>{date ? date.toLocaleDateString("en-GB", { day: "2-digit", month: "short" }) : "—"}</p>
                <p>{date ? `${date.getFullYear()} ·` : ""}</p>
                <p>{date ? date.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" }) : ""}</p>
              </div>
              {member.paid ? <span className="pill-active justify-self-center">ACTIVE</span> : <span className="pill-unpaid justify-self-center">UNPAID</span>}
              <div className="flex justify-center">
                {member.referredBy ? (
                  <span className="max-w-full truncate rounded-full border border-white/10 bg-white/10 px-2 py-1 text-[10px] font-bold">{member.referredBy}</span>
                ) : (
                  <span className="text-xs text-[#9aa3b2]">—</span>
                )}
              </div>
            </article>
          );
        })
      )}
    </section>
  );
}

function TestimonyDesk({
  rows,
  busy,
  onChange,
  onBusy,
}: {
  rows: AdminTestimony[];
  busy: boolean;
  onChange: (snapshot: AdminSnapshot) => void;
  onBusy: (busy: boolean) => void;
}) {
  async function run(task: Promise<AdminSnapshot>) {
    onBusy(true);
    try {
      onChange(await task);
    } finally {
      onBusy(false);
    }
  }

  return (
    <section className="mt-4 rounded-3xl border border-white/10 bg-[#111111]">
      <div className="px-4 py-4">
        <h2 className="text-xs font-extrabold tracking-[0.16em]">TESTIMONIES</h2>
      </div>
      {rows.length === 0 ? (
        <p className="border-t border-white/10 px-4 py-6 text-sm text-[#8b95a7]">No testimonies yet.</p>
      ) : (
        rows.map((row) => (
          <article key={row.id} className="flex flex-col gap-3 border-t border-[#333] px-4 py-4 md:flex-row md:items-center">
            <div className="min-w-0 flex-1">
              <p className="font-extrabold">
                {row.name} <span className="text-sm font-semibold text-[#8b95a7]">{row.place}</span> <span className="text-gold">{"★".repeat(row.stars)}</span>
              </p>
              <p className="mt-1 text-sm text-white/80">{row.text}</p>
              <span className={row.status === "approved" ? "pill-active mt-2" : "pill-unpaid mt-2"}>{row.status === "approved" ? "ACTIVE" : "UNPAID"}</span>
            </div>
            <div className="flex shrink-0 gap-2">
              {row.status === "pending" ? (
                <button type="button" disabled={busy} onClick={() => void run(setTestimonyStatus({ data: { id: row.id, status: "approved" } }))} className="h-8 rounded-lg bg-red px-3 text-[10px] font-extrabold text-white disabled:opacity-60">
                  APPROVE
                </button>
              ) : null}
              <button type="button" disabled={busy} onClick={() => void run(deleteTestimony({ data: { id: row.id } }))} className="h-8 rounded-lg border border-red/80 px-3 text-[10px] font-extrabold text-red disabled:opacity-60">
                DELETE
              </button>
            </div>
          </article>
        ))
      )}
    </section>
  );
}

function WeekRevenue({ payments, country }: { payments: AdminSnapshot["payments"]; country: "Ghana" | "Nigeria" }) {
  const nairaAmount = (amount: number) => amount === 35000 || amount === 55000 || amount === 75000;
  const dayKey = (value: Date | string) =>
    new Intl.DateTimeFormat("en-CA", { timeZone: "Africa/Accra", year: "numeric", month: "2-digit", day: "2-digit" }).format(
      value instanceof Date ? value : new Date(value),
    );
  const todayKey = dayKey(new Date());
  const weekdays = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
  const [year, month, day] = todayKey.split("-").map(Number);
  const rows = Array.from({ length: 7 }, (_, index) => {
    const date = new Date(Date.UTC(year, month - 1, day + (index - 6), 12));
    const key = dayKey(date);
    const approved = payments.filter((payment) => payment.status === "confirmed" && payment.confirmedAt && dayKey(payment.confirmedAt) === key);
    const ghana = approved.filter((payment) => !nairaAmount(payment.amount)).reduce((sum, payment) => sum + payment.amount, 0);
    const nigeria = approved.filter((payment) => nairaAmount(payment.amount)).reduce((sum, payment) => sum + payment.amount, 0);
    return {
      label: index === 6 ? "TODAY" : `${weekdays[date.getUTCDay()]} ${Number(key.slice(8))}`,
      text: country === "Ghana" ? `GHS ${ghana.toLocaleString("en-GH")}` : `₦${nigeria.toLocaleString("en-NG")}`,
    };
  });
  return (
    <section className="mt-4 overflow-hidden rounded-3xl border border-white/10 bg-[#111111]">
      <div className="flex items-center gap-3 px-5 py-5">
        <h2 className="text-lg font-black">Daily Revenue</h2>
        <span className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] font-bold text-[#9aa3b2]">{country}</span>
        <span className="rounded-full border border-white/10 px-2.5 py-1 text-[11px] font-bold text-[#9aa3b2]">last 7 days</span>
      </div>
      <ul>
        {rows.map((row) => (
          <li key={country + row.label} className="desk-row grid-cols-[2fr_1fr] text-sm">
            <span className={row.label === "TODAY" ? "font-extrabold text-red" : "font-bold text-[#9aa3b2]"}>{row.label}</span>
            <span className="text-[#8b95a7]">{row.text}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function StatCard({
  label,
  value,
  note,
  icon,
  gold = false,
  iconClass = "bg-white/10 text-red",
}: {
  label: string;
  value: string;
  note: string;
  icon: ReactNode;
  gold?: boolean;
  iconClass?: string;
}) {
  return (
    <article className="rounded-3xl border border-white/10 bg-[#111111] px-4 py-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-[11px] font-extrabold tracking-[0.14em] text-[#9aa3b2]">{label}</p>
        <span className={"grid size-9 place-items-center rounded-xl " + iconClass}>{icon}</span>
      </div>
      <p className={"mt-3 text-2xl font-black " + (gold ? "text-gold" : "text-white")}>{value}</p>
      <p className="mt-1 text-sm text-[#8b95a7]">{note}</p>
    </article>
  );
}
